function blowCandle() {
  const cake = document.getElementById("cake");
  const message = document.getElementById("message");

  // Menghilangkan kue setelah lilin dipadamkan
  cake.style.opacity = "0";
  setTimeout(() => {
    cake.style.display = "none";
    message.style.display = "block";
  }, 1000);
}

// Efek kembang api
const canvas = document.querySelector(".fireworks");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const particles = [];

function Particle(x, y, color) {
  this.x = x;
  this.y = y;
  this.size = Math.random() * 5 + 2;
  this.color = color;
  this.speedX = (Math.random() - 0.5) * 5;
  this.speedY = (Math.random() - 0.5) * 5;
}

Particle.prototype.update = function () {
  this.x += this.speedX;
  this.y += this.speedY;
  this.size *= 0.96;
};

Particle.prototype.draw = function () {
  ctx.fillStyle = this.color;
  ctx.beginPath();
  ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
  ctx.fill();
};

function createFirework(x, y) {
  for (let i = 0; i < 50; i++) {
    particles.push(
      new Particle(x, y, `hsl(${Math.random() * 360}, 100%, 50%)`)
    );
  }
  document.getElementById("fireworkSound").play();
}

function animate() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.1)";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  particles.forEach((particle, index) => {
    particle.update();
    particle.draw();
    if (particle.size < 0.5) {
      particles.splice(index, 1);
    }
  });

  requestAnimationFrame(animate);
}

setInterval(() => {
  createFirework(Math.random() * canvas.width, Math.random() * canvas.height);
}, 2000);

animate();
